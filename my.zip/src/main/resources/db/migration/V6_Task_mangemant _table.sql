CREATE TABLE tasks (

                       id BIGINT PRIMARY KEY AUTO_INCREMENT,
                       title VARCHAR(150) NOT NULL,
                       description TEXT,
                       priority VARCHAR(20) NOT NULL,
                       status VARCHAR(30) NOT NULL,
                       assigned_user_id BIGINT,
                       assigned_user_name VARCHAR(100),
                       field_name VARCHAR(100),
                       due_date DATE,
                       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);