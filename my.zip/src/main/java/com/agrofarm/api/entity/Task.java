package com.agrofarm.api.entity;

import com.agrofarm.api.util.TaskPriority;
import com.agrofarm.api.util.TaskStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Task {

    private Long id;
    private String title;
    private String description;
    private TaskPriority priority;
    private TaskStatus status;
    private Long assignedUserId;
    private String assignedUserName;
    private String fieldName;
    private LocalDate dueDate;
    private LocalDateTime createdAt;
}