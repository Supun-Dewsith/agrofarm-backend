package com.agrofarm.api.repository.impl;

import com.agrofarm.api.entity.Attendance;
import com.agrofarm.api.repository.AttendanceRepository;
import com.agrofarm.api.util.AttendanceStatus;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public class AttendanceRepositoryImpl {

    private final AttendanceRepository attendanceRepository;

    public AttendanceRepositoryImpl(AttendanceRepository attendanceRepository) {
        this.attendanceRepository = attendanceRepository;
    }

    public Attendance save(Attendance attendance) {
        return attendanceRepository.save(attendance);
    }

    public List<Attendance> findAll() {
        return attendanceRepository.findAll();
    }

    public Optional<Attendance> findById(Long id) {
        return attendanceRepository.findById(id);
    }

    public void deleteById(Long id) {
        attendanceRepository.deleteById(id);
    }

    public List<Attendance> findByStatus(AttendanceStatus status) {
        return attendanceRepository.findByStatus(status);
    }

    public List<Attendance> findByUserId(Long userId) {
        return attendanceRepository.findByUserId(userId);
    }

    public List<Attendance> findByAttendanceDate(LocalDate date) {
        return attendanceRepository.findByAttendanceDate(date);
    }

    public Attendance findByUserIdAndAttendanceDate(Long userId, LocalDate date) {
        return attendanceRepository.findByUserIdAndAttendanceDate(userId, date);
    }
}