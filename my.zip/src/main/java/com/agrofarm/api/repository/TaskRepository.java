package com.agrofarm.api.repository;

import com.agrofarm.api.entity.Task;

import java.util.List;
import java.util.Optional;

public interface TaskRepository {

    Task save(Task task);
    List<Task> findAll();
    Optional<Task> findById(Long id);
    Task update(Task task);
    void delete(Long id);

}