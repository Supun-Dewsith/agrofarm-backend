package com.agrofarm.api.repository;

import com.agrofarm.api.entity.Attendance;
import com.agrofarm.api.util.AttendanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

    List<Attendance> findByStatus(AttendanceStatus status);

    List<Attendance> findByUserId(Long userId);

    List<Attendance> findByAttendanceDate(LocalDate attendanceDate);

    Attendance findByUserIdAndAttendanceDate(Long userId, LocalDate attendanceDate);
}