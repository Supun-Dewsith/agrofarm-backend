package com.agrofarm.api.repository.impl;

import com.agrofarm.api.entity.Task;
import com.agrofarm.api.repository.TaskRepository;
import com.agrofarm.api.util.TaskPriority;
import com.agrofarm.api.util.TaskStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class TaskRepositoryImpl implements TaskRepository {

    private final JdbcTemplate template;

    @Override
    public Task save(Task task) {

        String sql = """
                INSERT INTO tasks
                (title, description, priority, status,
                 assigned_user_id, assigned_user_name,
                 field_name, due_date, created_at)
                VALUES (?,?,?,?,?,?,?,?,?)
                """;

        template.update(
                sql,
                task.getTitle(),
                task.getDescription(),
                task.getPriority().name(),
                task.getStatus().name(),
                task.getAssignedUserId(),
                task.getAssignedUserName(),
                task.getFieldName(),
                task.getDueDate(),
                task.getCreatedAt()
        );

        String findSql = """
                SELECT *
                FROM tasks
                WHERE title = ?
                ORDER BY id DESC
                LIMIT 1
                """;

        return template.queryForObject(findSql, (rs, rowNum) -> {

            Task t = new Task();

            t.setId(rs.getLong("id"));
            t.setTitle(rs.getString("title"));
            t.setDescription(rs.getString("description"));
            t.setPriority(TaskPriority.valueOf(rs.getString("priority")));
            t.setStatus(TaskStatus.valueOf(rs.getString("status")));
            t.setAssignedUserId(rs.getLong("assigned_user_id"));
            t.setAssignedUserName(rs.getString("assigned_user_name"));
            t.setFieldName(rs.getString("field_name"));
            t.setDueDate(rs.getObject("due_date", LocalDate.class));
            t.setCreatedAt(rs.getObject("created_at", LocalDateTime.class));

            return t;

        }, task.getTitle());

    }

    @Override
    public List<Task> findAll() {

        String sql = "SELECT * FROM tasks ORDER BY created_at DESC";

        return template.query(sql, (rs, rowNum) -> {

            Task task = new Task();

            task.setId(rs.getLong("id"));
            task.setTitle(rs.getString("title"));
            task.setDescription(rs.getString("description"));
            task.setPriority(TaskPriority.valueOf(rs.getString("priority")));
            task.setStatus(TaskStatus.valueOf(rs.getString("status")));
            task.setAssignedUserId(rs.getLong("assigned_user_id"));
            task.setAssignedUserName(rs.getString("assigned_user_name"));
            task.setFieldName(rs.getString("field_name"));
            task.setDueDate(rs.getObject("due_date", LocalDate.class));
            task.setCreatedAt(rs.getObject("created_at", LocalDateTime.class));

            return task;
        });

    }

    @Override
    public Optional<Task> findById(Long id) {

        String sql = "SELECT * FROM tasks WHERE id=?";

        try {

            Task task = template.queryForObject(sql, (rs, rowNum) -> {

                Task t = new Task();

                t.setId(rs.getLong("id"));
                t.setTitle(rs.getString("title"));
                t.setDescription(rs.getString("description"));
                t.setPriority(TaskPriority.valueOf(rs.getString("priority")));
                t.setStatus(TaskStatus.valueOf(rs.getString("status")));
                t.setAssignedUserId(rs.getLong("assigned_user_id"));
                t.setAssignedUserName(rs.getString("assigned_user_name"));
                t.setFieldName(rs.getString("field_name"));
                t.setDueDate(rs.getObject("due_date", LocalDate.class));
                t.setCreatedAt(rs.getObject("created_at", LocalDateTime.class));

                return t;

            }, id);

            return Optional.ofNullable(task);

        } catch (EmptyResultDataAccessException e) {

            return Optional.empty();

        }

    }

    @Override
    public Task update(Task task) {

        String sql = """
                UPDATE tasks
                SET title=?,
                    description=?,
                    priority=?,
                    status=?,
                    assigned_user_id=?,
                    assigned_user_name=?,
                    field_name=?,
                    due_date=?
                WHERE id=?
                """;

        template.update(
                sql,
                task.getTitle(),
                task.getDescription(),
                task.getPriority().name(),
                task.getStatus().name(),
                task.getAssignedUserId(),
                task.getAssignedUserName(),
                task.getFieldName(),
                task.getDueDate(),
                task.getId()
        );

        return findById(task.getId()).orElse(null);

    }

    @Override
    public void delete(Long id) {

        String sql = "DELETE FROM tasks WHERE id=?";

        template.update(sql, id);

    }

}
