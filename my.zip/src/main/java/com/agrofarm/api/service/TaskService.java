package com.agrofarm.api.service;

import com.agrofarm.api.dto.TaskRequest;
import com.agrofarm.api.entity.Task;

import java.util.List;

public interface TaskService {

    Task create(TaskRequest request);
    List<Task> getAll();
    Task getById(Long id);
    Task update(Long id, TaskRequest request);
    void delete(Long id);

}