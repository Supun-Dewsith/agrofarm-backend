package com.agrofarm.api.service.impl;

import com.agrofarm.api.dto.TaskRequest;
import com.agrofarm.api.entity.Task;
import com.agrofarm.api.entity.UserEntity;
import com.agrofarm.api.repository.TaskRepository;
import com.agrofarm.api.repository.UserRepository;
import com.agrofarm.api.service.TaskService;
import com.agrofarm.api.util.TaskStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    @Override
    public Task create(TaskRequest request) {

        Task task = new Task();

        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setPriority(request.getPriority());

        // Status එක නැත්නම් Pending
        task.setStatus(
                request.getStatus() == null
                        ? TaskStatus.PENDING
                        : request.getStatus()
        );

        task.setAssignedUserId(request.getAssignedUserId());

        if (request.getAssignedUserId() != null) {

            UserEntity user = userRepository
                    .findById(request.getAssignedUserId())
                    .orElse(null);

            if (user != null) {
                task.setAssignedUserName(user.getUsername());
            }

        }

        task.setFieldName(request.getFieldName());
        task.setDueDate(request.getDueDate());
        task.setCreatedAt(LocalDateTime.now());

        return taskRepository.save(task);
    }

    @Override
    public List<Task> getAll() {

        return taskRepository.findAll();

    }

    @Override
    public Task getById(Long id) {

        return taskRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Task not found"));

    }

    @Override
    public Task update(Long id, TaskRequest request) {

        Task task = taskRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Task not found"));

        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setPriority(request.getPriority());
        task.setStatus(request.getStatus());
        task.setFieldName(request.getFieldName());
        task.setDueDate(request.getDueDate());

        task.setAssignedUserId(request.getAssignedUserId());

        if (request.getAssignedUserId() != null) {

            UserEntity user = userRepository
                    .findById(request.getAssignedUserId())
                    .orElse(null);

            if (user != null) {
                task.setAssignedUserName(user.getUsername());
            }

        }

        return taskRepository.update(task);

    }

    @Override
    public void delete(Long id) {

        taskRepository.delete(id);

    }

}