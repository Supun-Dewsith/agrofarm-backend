package com.agrofarm.api.service;

import com.agrofarm.api.dto.AttendanceRequest;
import com.agrofarm.api.dto.AttendanceResponse;
import com.agrofarm.api.dto.QrAttendanceRequest;
import com.agrofarm.api.dto.QrAttendanceResponse;
import com.agrofarm.api.dto.attendance.AttendanceDashboardResponse;

import java.time.LocalDate;
import java.util.List;

public interface AttendanceService {

    AttendanceResponse create(AttendanceRequest request);

    AttendanceResponse update(Long id, AttendanceRequest request);

    AttendanceResponse findById(Long id);

    List<AttendanceResponse> findAll();

    void delete(Long id);

    AttendanceDashboardResponse getDashboard(LocalDate date);

    QrAttendanceResponse markAttendance(QrAttendanceRequest request);
}