package com.agrofarm.api.controller;

import com.agrofarm.api.dto.QrAttendanceRequest;
import com.agrofarm.api.dto.attendance.AttendanceDashboardResponse;
import com.agrofarm.api.dto.QrAttendanceResponse;
import com.agrofarm.api.entity.Attendance;
import com.agrofarm.api.service.AttendanceService;
import com.agrofarm.api.util.AttendanceStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;

    public AttendanceController(AttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @PostMapping
    public ResponseEntity<Attendance> save(@RequestBody Attendance attendance) {
        return ResponseEntity.ok(attendanceService.save(attendance));
    }

    @GetMapping
    public ResponseEntity<List<Attendance>> findAll() {
        return ResponseEntity.ok(attendanceService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Attendance> findById(@PathVariable Long id) {

        return attendanceService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Attendance> update(
            @PathVariable Long id,
            @RequestBody Attendance attendance) {

        return ResponseEntity.ok(attendanceService.update(id, attendance));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        attendanceService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Attendance>> findByStatus(
            @PathVariable AttendanceStatus status) {

        return ResponseEntity.ok(attendanceService.findByStatus(status));
    }

    @GetMapping("/dashboard")
    public ResponseEntity<AttendanceDashboardResponse> dashboard() {

        return ResponseEntity.ok(attendanceService.getDashboardData());
    }

    @PostMapping("/qr")
    public ResponseEntity<QrAttendanceResponse> scanQr(
            @RequestBody QrAttendanceRequest request) {

        return ResponseEntity.ok(attendanceService.scanQr(request));
    }
}