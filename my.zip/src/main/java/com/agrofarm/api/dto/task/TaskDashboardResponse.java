package com.agrofarm.api.dto.task;

import com.agrofarm.api.entity.Task;

import java.util.List;

public record TaskDashboardResponse(

        int totalTasks,
        int pendingTasks,
        int inProgressTasks,
        int completedTasks,
        List<Task> tasks

) {
}
