package com.agrofarm.api.dto;

public record QrAttendanceResponse(
        boolean success,
        String message,
        Long attendanceId
) {
}