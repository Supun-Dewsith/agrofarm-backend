package com.agrofarm.api.dto;

public class QrAttendanceRequest {

    private String qrCode;

    public QrAttendanceRequest() {
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public static record QrAttendanceResponse(

            String qrToken,

            String qrContent,

            String expiresAt

    ) {
    }
}