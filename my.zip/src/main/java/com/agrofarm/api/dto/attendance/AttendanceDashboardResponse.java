package com.agrofarm.api.dto.attendance;

public record AttendanceDashboardResponse(
        long totalWorkers,
        long presentWorkers,
        long absentWorkers,
        long lateWorkers
) {
}